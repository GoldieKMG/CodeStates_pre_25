(function() {
  'use strict';

  window._ = {};

  // Returns whatever value is passed as the argument. This function doesn't
  // seem very useful, but remember it--if a function needs to provide an
  // iterator when the user does not pass one in, this will be handy.
  _.identity = function(val) {
    return val;
  };

  /**
   * COLLECTIONS
   * ===========
   *
   * In this section, we'll have a look at functions that operate on collections
   * of values; in JavaScript, a 'collection' is something that can contain a
   * number of values--either an array or an object.
   *
   *
   * IMPORTANT NOTE!
   * ===========
   *
   * The .first function is implemented for you, to help guide you toward success
   * in your work on the following functions. Whenever you see a portion of the
   * assignment pre-completed, be sure to read and understand it fully before
   * you proceed. Skipping this step will lead to considerably more difficulty
   * implementing the sections you are responsible for.
   */

  // Return an array of the first n elements of an array. If n is undefined,
  // return just the first element.
  _.first = function(array, n) {
    return n === undefined ? array[0] : array.slice(0, n);
  };

  // Like first, but for the last elements. If n is undefined, return just the
  // last element.
  _.last = function(array, n) {
    var indexlangth;
    if(array.length < n){
      indexlangth = array.length;
    }else{
      indexlangth = n;
    }
    var indexlength = array.length < n ? 0 : array.length - n;
    // slice함수는 앞에있는 수를 절대값으로 인식.
    return n === undefined ? array[array.length-1] : array.slice(indexlength, array.length)
  };

  // Call iterator(value, key, collection) for each element of collection.
  // Accepts both arrays and objects.
  //
  // Note: _.each does not have a return value, but rather simply runs the
  // iterator function over each item in the input collection.
  _.each = function(collection, iterator) {
    if(Array.isArray(collection)){
      for(var i = 0; i < collection.length; i++ ){
        iterator(collection[i], i, collection);
      }
    }else if(typeof collection === 'object'){
      for(var key in collection){
          iterator(collection[key], key, collection);
      }
    }
    // if ( collection.constructor === Array ){
    //   for ( var i = 0 ; i < collection.length ; i ++ ){
    //     iterator(collection[i], i, collection);
    //   }
    // }
    // else if ( collection.constructor === Object ){
    //   for ( var key in collection ){
    //     iterator(collection[key], key, collection);
    //   }
    // }
  };

  // Returns the index at which value can be found in the array, or -1 if value
  // is not present in the array.
  _.indexOf = function(array, target) {
    // TIP: Here's an example of a function that needs to iterate, which we've
    // implemented for you. Instead of using a standard `for` loop, though,
    // it uses the iteration helper `each`, which you will need to write.
    var result = -1;

    _.each(array, function(item, index) {
      if (item === target && result === -1) {
        result = index;
      }
    });

    return result;
  };


  // 각 함수에 조건에 맞는것들을 배열에서 순환을 돌아서 걸러준후 돌려줌.
  // Return all elements of an array that pass a truth test.
  _.filter = function(collection, test) {
    var newCollection = [];
    for(var i = 0 ; i < collection.length; i++){
      if(test(collection[i])){
        newCollection.push(collection[i]);
      }
    }
    return newCollection;
  };


  // Return all elements of an array that don't pass a truth test.
  _.reject = function(collection, test) {
    // TIP: see if you can re-use _.filter() here, without simply
    // copying code in and modifying it
    var newCollection = [];
    for(var i = 0 ; i < collection.length; i++){
      if(!test(collection[i])){
        newCollection.push(collection[i]);
      }
    }
    return newCollection;
  };


  // 중복 제거하는 문법.
  // 새로운 배열을 생성. 새로운 배열과 입력에들어온배열 요소를 비교.
  // Produce a duplicate-free version of the array.
  _.uniq = function(array) {
    
    array = array.sort();
    var result = [];
    for (var i = 0; i < array.length; i++) {
      if (array[i] !== array[i+1]) {
        result.push(array[i]);
      }
    }
    return result;

    // var newArray = [];
    // newArray.push(array[0]);

    // var isExist = function(element, newArray){
    //   for(var i = 0 ; i < newArray.length; i++){
    //     if(element === newArray[i]){
    //       return false;
    //     }
    //   }
    //   return true;
    // }

    // for(var i = 1 ; i < array.length ; i++){
    //   if(isExist(array[i], newArray)){
    //     newArray.push(array[i])
    //   }
    // }
    //   return newArray;
  };


  // Return the results of applying an iterator to each element.
  _.map = function(collection, iterator) {
     // map() is a useful primitive iteration function that works a lot
    // like each(), but in addition to running the operation on all
    // the members, it also maintains an array of results.
    var result = [];
    if(Array.isArray(collection)){
      for(var i=0; i < collection.length; i++){
        result.push(iterator(collection[i],i,collection));
      }
    }else{
      for(var prop in collection){
        result.push(iterator(collection[prop],prop,collection))
      }
    }
    return result;
/*
풀어본 후 다른 코드 참고. 대조해보니 비슷함.
  var res = [];
  if (Array.isArray(collection)) {
    for (var i = 0, len = collection.length; i < len; i++) 
      res[i] = iterator(collection[i], i, collection);
  } else {
    var keys = Object.keys(collection);
    for (var i = 0, len = keys.length; i < len; i++) 
      res[i] = iterator(collection[keys[i]], keys[i], collection);
  }
  return res;
*/

  };

  /*
   * TIP: map is really handy when you want to transform an array of
   * values into a new array of values. _.pluck() is solved for you
   * as an example of this.
   */

  // Takes an array of objects and returns and array of the values of
  // a certain property in it. E.g. take an array of people and return
  // an array of just their ages
  _.pluck = function(collection, key) {
    // TIP: map is really handy when you want to transform an array of
    // values into a new array of values. _.pluck() is solved for you
    // as an example of this.
    return _.map(collection, function(item) {
      return item[key];
    });
  };

  // Reduces an array or object to a single value by repetitively calling
  // iterator(accumulator, item) for each item. accumulator should be
  // the return value of the previous iterator call.
  //  
  // You can pass in a starting value for the accumulator as the third argument
  // to reduce. If no starting value is passed, the first element is used as
  // the accumulator, and is never passed to the iterator. In other words, in
  // the case where a starting value is not passed, the iterator is not invoked
  // until the second element, with the first element as its second argument.
  //  
  // Example:
  //   var numbers = [1,2,3];
  //   var sum = _.reduce(numbers, function(total, number){
  //     return total + number;
  //   }, 0); // should be 6
  //  
  //   var identity = _.reduce([5], function(total, number){
  //     return total + number * number;
  //   }); // should be 5, regardless of the iterator function passed in
  //          No accumulator is given so the first element is used.
  // 주어진 iter에 대해서 수행하여 결과값을 도출 해주는 펑션.
  _.reduce = function(collection, iterator, accumulator) {
    //개인적으로 공부하면서 풀어본 후 https://joeun.me/programming/functional-js-study/ 사이트 참고해서 다시 공부함.
    //accmulator 초기값을 주지 않을 시 첫번째, 주어줄시 그대로 사용. 
  var i = 0;
  if (Array.isArray(collection)) {
    var res = (accumulator !== undefined ? accumulator : collection[i++]); // <-- 남다른 결과값 선언부
    for (var len = collection.length; i < len; i++) 
      res = iterator(res, collection[i], i, collection);
  } else {
    var keys = Object.keys(collection), res = (accumulator !== undefined ? accumulator : collection[keys[i++]]);
    for (var len = keys.length; i < len; i++)
      res = iterator(res, collection[keys[i]], keys[i], collection);
  }
  return res;


/*
    if (accumulator === undefined) {
      accumulator = collection[0];
      for (var i = 1; i < collection.length; i++) {
        accumulator = iterator(accumulator, collection[i]);
      }
    } else {
      for (var i = 0; i < collection.length; i++) {
        accumulator = iterator(accumulator, collection[i]);
      }
    }
    return accumulator;
*/
  };


  // Determine if the array or object contains a given value (using `===`).
  _.contains = function(collection, target) {
    // TIP: Many iteration problems can be most easily expressed in
    // terms of reduce(). Here's a freebie to demonstrate!
    // Object.values Fn은 object의 value들을 배열로 바꿔준다. 
    collection = Object.values(collection);
    return _.reduce(collection, function(wasFound, item) {
      if (wasFound) {
        return true;
      }
      return item === target;
    }, false)
  };


  // Determine whether all of the elements match a truth test.
  // reuduce : collection준 것에 대해서 순회를 돌며 iter조건을 체크함.
  _.every = function(collection, iterator) {
    // // TIP: Try re-using reduce() here. 
    // // every Fn은 iterator이 모두 true일경우 true 만약 1개라도 false 이면 false 즉, All true일 시 ture 반환.
  
  if(iterator === undefined){
    iterator = function(element){
      return element;
    }
  
  var len = collection.length >>> 0;
  for(var i = 0; i < len ; i++){
    
  }
  }
  
  //   if(collection === undefined){return true;}
  //   //iterator가 Fn일때와 아닐때를 구분.
  //   if(iterator === undefined){
  //     for(var i = 0; i<collection.length ;i++){
  //       if(!collection[i]){
  //         return false;
  //       }
  //     }
  //     return true;
  //   }else{
  //     return _.reduce(collection,function(condition,item){
  //       if(condition === false){
  //         return false;
  //       }else if(iterator(item)){
  //         return true;
  //       }else{
  //         return false;
  //       }
  //     },true)
  // }
}



  // Determine whether any of the elements pass a truth test. If no iterator is
  // provided, provide a default one
  _.some = function(collection, iterator) {
  // your code here
  if(typeof iterator === 'undefined') {
    iterator = function(element) {
      return element;
    }
  }

  var len = collection.length >>> 0;

  for (var i = 0; i < len; i++) {
    if (i in collection && iterator.call(this, collection[i], i, collection)) {
      return true;
    }
  }

  return false;
    // if(collection === undefined){return true;}
    // //iterator가 Fn일때와 아닐때를 구분.
    // if(iterator === undefined){
    //   for(var i = 0; i<collection.length ;i++){
    //     if(collection[i]){ return true; }
    //   }
    //   return false;
    // }else if(!collection){return true;}
    // return _.reduce(collection,function(condition,item){
    //   if(condition === true){
    //     return true;
    //   }else if(iterator(item)){
    //     return true;
    //   }else{
    //     return false;
    //   }
    // },false)
  };


  /**
   * OBJECTS
   * =======
   *
   * In this section, we'll look at a couple of helpers for merging objects.
   */

  // Extend a given object with all the properties of the passed in
  // object(s).
  //
  // Example:
  //   var obj1 = {key1: "something"};
  //   _.extend(obj1, {
  //     key2: "something new",
  //     key3: "something else new"
  //   }, {
  //     bla: "even more stuff"
  //   }); // obj1 now contains key1, key2, key3 and bla
  _.extend = function(obj) {
    for(var i = 1; i < arguments.length; i++ ){
      for(var prop in arguments[i]){
        obj[prop] = arguments[i][prop];
      }
    }
    return obj;
  };
  // Like extend, but doesn't ever overwrite a key that already
  // exists in obj
  _.defaults = function(obj) {
    for(var i = 1; i < arguments.length; i++ ){
      for(var prop in arguments[i]){
        if(!obj.hasOwnProperty(prop))
        obj[prop] = arguments[i][prop];
      }
    }
    return obj;
  };


  /**
   * FUNCTIONS
   * =========
   *
   * Now we're getting into function decorators, which take in any function
   * and return out a new version of the function that works somewhat differently
   */

  // Return a function that can be called at most one time. Subsequent calls
  // should return the previously returned value.
  _.once = function(func) {
    // TIP: These variables are stored in a "closure scope" (worth researching),
    // so that they'll remain available to the newly-generated function every
    // time it's called.
    var alreadyCalled = false;
    var result;

    // TIP: We'll return a new function that delegates to the old one, but only
    // if it hasn't been called before.
    return function() {
      if (!alreadyCalled) {
        // TIP: .apply(this, arguments) is the standard way to pass on all of the
        // infromation from one function call to another.
        result = func.apply(this, arguments);
        alreadyCalled = true;
      }
      // The new function always returns the originally computed result.
      return result;
    };
  };

  // Memorize an expensive function's results by storing them. You may assume
  // that the function only takes primitives as arguments.
  // memoize could be renamed to oncePerUniqueArgumentList; memoize does the
  // same thing as once, but based on many sets of unique arguments.
  //
  // _.memoize should return a function that, when called, will check if it has
  // already computed the result for the given argument and return that value
  // instead if possible.
  _.memoize = function(func) {
    var cache = {};
    return function() {
      var key = JSON.stringify(arguments);
      if(cache[key]) {
        return cache[key];
      }
      else {
        var val = func.apply(this, arguments);
        cache[key] = val;
        return val;
      }
    };
  };

  // Delays a function for the given number of milliseconds, and then calls
  // it with the arguments supplied.
  //
  // The arguments for the original function are passed after the wait
  // parameter. For example _.delay(someFunction, 500, 'a', 'b') will
  // call someFunction('a', 'b') after 500ms
  /*
  Internet Explorer, Chrome, Safari, and Firefox 포함하는 브라우저들은 내부적으로 32-bit 부호있는 정수로 지연 값을 저장합니다.
  이로 인해 2147483647보다 더 큰 지연을 사용할 때 정수 오버플로우가 발생하여, 타임아웃이 즉시 실행됩니다.
  */
  _.delay = function(func, wait) {
    // var argsArr = []
    // for(var i = 2; i < arguments.length;i++){
    //   argsArr.push(arguments[i]);
    // }
    //argumets는 배열처럼 동작할뿐, 실제 배열이 아니다. 그래서 Array prototype의 slice를 바로 쓸 수가 없다. 따라서 
    var args = Array.prototype.slice.call(arguments, 2);
    // var args = (arguments.length === 1 ? [arguments[0]] : Array.apply(null, arguments));
    // return setTimeout(func,wait,arguments[2],arguments[3])
    return setTimeout(function(){
            func.apply(null,args);
    },wait)
  };


  /**
   * ADVANCED COLLECTION OPERATIONS
   * ==============================
   */

  // Randomizes the order of an array's contents.
  //
  // TIP: This function's test suite will ask that you not modify the original
  // input array. For a tip on how to make a copy of an array, see:
  // http://mdn.io/Array.prototype.slice
  _.shuffle = function(array) {
  };


  /**
   * ADVANCED
   * =================
   *
   * Note: This is the end of the pre-course curriculum. Feel free to continue,
   * but nothing beyond here is required.
   */

  // Calls the method named by functionOrKey on each value in the list.
  // Note: You will need to learn a bit about .apply to complete this.
  _.invoke = function(collection, functionOrKey, args) {
  };

  // Sort the object's values by a criterion produced by an iterator.
  // If iterator is a string, sort objects by that property with the name
  // of that string. For example, _.sortBy(people, 'name') should sort
  // an array of people by their name.
  _.sortBy = function(collection, iterator) {
  };

  // Zip together two or more arrays with elements of the same index
  // going together.
  //
  // Example:
  // _.zip(['a','b','c','d'], [1,2,3]) returns [['a',1], ['b',2], ['c',3], ['d',undefined]]
  _.zip = function() {
  };

  // Takes a multidimensional array and converts it to a one-dimensional array.
  // The new array should contain all elements of the multidimensional array.
  //
  // Hint: Use Array.isArray to check if something is an array
  _.flatten = function(nestedArray, result) {
  };

  // Takes an arbitrary number of arrays and produces an array that contains
  // every item shared between all the passed-in arrays.
  _.intersection = function() {
  };

  // Take the difference between one array and a number of other arrays.
  // Only the elements present in just the first array will remain.
  _.difference = function(array) {
  };

  // Returns a function, that, when invoked, will only be triggered at most once
  // during a given window of time.  See the Underbar readme for extra details
  // on this function.
  //
  // Note: This is difficult! It may take a while to implement.
  _.throttle = function(func, wait) {
  };
}());
